// Justin Yeh
// 101400171
// COMP 3123
// Lecture Time: Thursdays from 6pm-8pm
// Lab Time: Fridays from 12pm-2pm

const express = require('express');
const app = express();


const port = process.env.PORT || 3001;
console.log("http://127.0.0.1:3001/");

// GET
let data = '<h3>Hello Express JS!</h3>'

// http://127.0.0.1:3001/hello
app.get('/hello', (req, res) => {
    res.send(data);
});


// http://127.0.0.1:3001/user?firstName=Justin&lastName=Yeh
app.get('/user', (req, res) => {
    const userFirstName = req.query.firstName;
    const userLastName = req.query.lastName;
    res.json(`firstname: ${userFirstName}, lastname: ${userLastName}`);
})

// POST

app.use(express.json());

// http://127.0.0.1:3001/user/Justin/Yeh
app.post('/user/:firstName/:lastName', (req, res) => {
    const userFirstName = req.params.firstName;
    const userLastName = req.params.lastName;
    res.json(`firstname: ${userFirstName}, lastname: ${userLastName}`);
});

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});